from base64 import b64encode
with open('data.csv','r',encoding='utf-8') as f:
    data = b64encode(f.read().encode()).decode()
for i in range(len(data)//4000+1):
    with open(f'out{i+1}.txt','w') as f:
        f.write(data[i*4000:(i+1)*4000])